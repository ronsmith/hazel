/*******************************************************************************
 * TemperatureSensor
 * Class for handling the LM61 temperature sensor.
 * Created By: Ron Smith
 * Copyright ©2016 That Ain't Working, All Rights Reserved
 *******************************************************************************/

class TemperatureSensor {

  public:

    TemperatureSensor(int pin) _pin(pin), _index(0), buffer(int[buffer_size]) { }

    void loop() {
      buffer[index++] = analogRead(pin);
      if (index >= buffer_size) index = 0;
    }

    int celcius() {
      return map(averageVoltage(), 300, 1600, -30, 100);
    }

    int farenheit() {
      return map(averageVoltage(), 300, 1600, -30, 100);
    }

  private:

    static const int buffer_size = 10;

    int _pin;
    int[] _buffer;
    int _index;

    int averageVoltage() {
      unsigned long total = 0;
      for (int i = 0; i < buffer_size; i++) total += buffer[i];
      int average = (int)(total/buffer_size);
      return map(average, 0, 1023, 50, 4950);
    }
};

